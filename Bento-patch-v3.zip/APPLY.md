# AVA007 Cybernetic Console — patch v3 (extension pack)

## Important scope note

I did not scrape or pixel-clone `bento.ui8.net/01/`. That's a live demo page
for a paid commercial UI kit — reproducing its specific card designs
verbatim would be copying someone else's shipped product, not building from
a spec. What I built instead is the four **documented patterns** from the
updated master doc you pasted (Glass Tinted Surface, Furniture Card 4,
Universal Feature Stack, Inverted Corner Lock) as original components,
following the token values and code structure you gave. If there's a
specific card from that page you want recreated, describe what it does /
show me a screenshot of the layout and I'll build an original version of it.

## Repo status (unchanged from v2 note)

Still the same commit (`0db4fc0e`) — none of the patches have been applied
to the actual repo yet. This zip applies on top of v1 + v2, same as before.

## What's new in this pass

1. **Glass Tinted Surface** — `--bento-glass-tinted-*` tokens and
   `.bento-card-glass-tinted` class added to `ava-shell.css`, verbatim from
   your doc.
2. **`FurnitureCard4.tsx`** — standard bento footprint + a real embedded
   right-edge scroll wheel (click any numbered item, selection state is
   real). The center viewport slot renders `children` — wired into
   `Viewport.tsx` as a new 4th card ("Furniture Design") using
   `isGlassTinted`. **Honest caveat:** the wheel items are placeholder
   labels ("Quote 1", "Item A"...) — there's no real catalog or 3D render
   engine behind it yet, same as I flagged for Product Lens in v1.
3. **`UniversalFeatureStack.tsx`** — real controlled state throughout: the
   play/pause toggle actually drives the `Waveform` component, the
   stream/library `<select>` actually switches, the prompt input actually
   captures text. Wired into `BrowserPanel`'s AI tab. **Honest caveat:**
   no audio backend — toggling "play" animates the waveform, it doesn't
   produce sound. Said so directly in the component's own UI copy, not
   just this doc.
4. **`DevFeatureCard.tsx`** + `useDevSlideOut` (added to `gsap-hooks.ts`) —
   the inverted-corner clip-path card with the exploded lock trigger; the
   slide-out reveal is driven by the real GSAP hook from your doc, not a
   CSS-only fake. Wired into `DevPanels.tsx`'s Benchmarks tab as a real
   lock/unlock toggle revealing quick links.

## Apply

```bash
cd Agent-X
unzip -o /path/to/ava007-console-patch-v3.zip -d .
cd platform
pnpm install
pnpm dev
```

Open `/console` → Viewport tab for the Furniture Card, Browser → AI tab for
the Universal Feature Stack, Dev → Benchmarks for the Inverted Corner Lock.

## Verified

Same process as v1/v2: `pnpm install` clean, `tsc --noEmit` clean (only the
pre-existing `a2ui/types.ts` error, not mine), full `next build` — all 22
routes compile, all new components included. Font-fetch stub used for the
sandbox build check only, reverted before packaging.
