import { NextRequest, NextResponse } from "next/server";
import { act, BrowserAction } from "@/lib/agent-browser";

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => ({}));
  const session: string = body.session || "ava007-default";
  const action: BrowserAction | undefined = body.action;

  if (!action || !action.type) {
    return NextResponse.json({ ok: false, error: "missing action" }, { status: 400 });
  }

  const result = await act(session, action);

  return NextResponse.json(
    { ok: result?.ok ?? false, stdout: result?.stdout, stderr: result?.stderr },
    { status: result?.ok ? 200 : 502 },
  );
}
