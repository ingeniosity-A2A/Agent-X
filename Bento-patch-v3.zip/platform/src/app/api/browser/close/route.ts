import { NextRequest, NextResponse } from "next/server";
import { closeSession } from "@/lib/agent-browser";

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => ({}));
  const session: string = body.session || "ava007-default";
  const result = await closeSession(session);
  return NextResponse.json({ ok: result.ok, stdout: result.stdout, stderr: result.stderr });
}
