import { NextRequest, NextResponse } from "next/server";
import { openSession } from "@/lib/agent-browser";

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => ({}));
  const session: string = body.session || "ava007-default";
  const url: string | undefined = body.url;

  const result = await openSession({ session, url, headless: true });

  return NextResponse.json(
    {
      ok: result.ok,
      session,
      stdout: result.stdout,
      stderr: result.stderr,
      hint: result.ok
        ? undefined
        : "agent-browser CLI not reachable on this host. Install with `npm install -g agent-browser && agent-browser install` (see agent-browser.dev/installation), or set AGENT_BROWSER_BIN.",
    },
    { status: result.ok ? 200 : 502 },
  );
}
