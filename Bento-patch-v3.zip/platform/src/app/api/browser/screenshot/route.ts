import { NextRequest, NextResponse } from "next/server";
import { screenshot } from "@/lib/agent-browser";

// agent-browser prints base64 PNG to stdout when no output path is given.
export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const session = searchParams.get("session") || "ava007-default";
  const full = searchParams.get("full") === "1";
  const annotate = searchParams.get("annotate") === "1";

  const result = await screenshot(session, { full, annotate });

  if (!result.ok || !result.stdout.trim()) {
    return NextResponse.json(
      { ok: false, error: result.stderr || "no screenshot data" },
      { status: 502 },
    );
  }

  const base64 = result.stdout.trim();
  const bytes = Buffer.from(base64, "base64");

  return new NextResponse(bytes, {
    status: 200,
    headers: {
      "Content-Type": "image/png",
      "Cache-Control": "no-store",
    },
  });
}
