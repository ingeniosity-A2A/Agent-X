import { NextRequest, NextResponse } from "next/server";
import { snapshot } from "@/lib/agent-browser";

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const session = searchParams.get("session") || "ava007-default";
  const interactive = searchParams.get("i") !== "0"; // default true
  const compact = searchParams.get("c") !== "0"; // default true

  const result = await snapshot(session, { interactive, compact });

  let parsed: unknown = null;
  try {
    parsed = JSON.parse(result.stdout);
  } catch {
    // agent-browser --json failed to parse — fall back to raw text
  }

  return NextResponse.json(
    { ok: result.ok, raw: result.stdout, parsed, stderr: result.stderr },
    { status: result.ok ? 200 : 502 },
  );
}
