import { NextRequest, NextResponse } from "next/server";
import { listTabs, newTab } from "@/lib/agent-browser";

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const session = searchParams.get("session") || "ava007-default";
  const result = await listTabs(session);
  let parsed: unknown = null;
  try {
    parsed = JSON.parse(result.stdout);
  } catch {
    // ignore parse failure, raw is still returned
  }
  return NextResponse.json({ ok: result.ok, parsed, raw: result.stdout });
}

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => ({}));
  const session: string = body.session || "ava007-default";
  const result = await newTab(session, body.url);
  return NextResponse.json({ ok: result.ok, stdout: result.stdout, stderr: result.stderr });
}
