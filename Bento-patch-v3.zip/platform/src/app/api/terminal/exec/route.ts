import { NextRequest, NextResponse } from "next/server";
import { exec } from "node:child_process";

/**
 * Exoskeleton Bash capability — single command execution.
 *
 * NOTE on scope: this executes one command per request and returns
 * stdout/stderr/exit code. It is a real exec surface, not a fake terminal —
 * but it is not a persistent PTY (no interactive programs like vim/htop,
 * no ANSI cursor control, no long-lived shell state between calls beyond
 * `cwd`). Wiring a true PTY (node-pty + a WebSocket route) is the next-phase
 * item for the Linux/Termux terminal tabs; this route is the safe, working
 * baseline for Bash-context one-shot commands (git status, ls, cat, curl
 * against allowed hosts, etc).
 *
 * `context` selects which logical terminal is issuing the command
 * (bash | linux | termux) purely for labeling/telemetry — all three
 * currently execute in the same server process. Route them to distinct
 * hosts (e.g. SSH to the Hetzner box for "linux", ADB/Termux bridge for
 * "termux") by branching on `context` here once those backends exist.
 */

const DENYLIST = /\b(rm\s+-rf\s+\/|:(){:|mkfs|dd\s+if=)/i;

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => ({}));
  const command: string = body.command ?? "";
  const cwd: string = body.cwd || process.env.HOME || "/tmp";
  const context: string = body.context || "bash";

  if (!command.trim()) {
    return NextResponse.json({ ok: false, error: "empty command" }, { status: 400 });
  }
  if (DENYLIST.test(command)) {
    return NextResponse.json(
      { ok: false, error: "command blocked by safety denylist", context },
      { status: 403 },
    );
  }

  return new Promise<NextResponse>((resolve) => {
    exec(
      command,
      { cwd, timeout: 15_000, maxBuffer: 1024 * 1024 * 8, shell: "/bin/bash" },
      (error, stdout, stderr) => {
        resolve(
          NextResponse.json({
            ok: !error,
            context,
            cwd,
            command,
            stdout,
            stderr,
            code: error ? (error as unknown as { code?: number }).code ?? 1 : 0,
          }),
        );
      },
    );
  });
}
