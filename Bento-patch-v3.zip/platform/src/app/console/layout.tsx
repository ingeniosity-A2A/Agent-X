import "./ava-shell.css";

export default function ConsoleLayout({ children }: { children: React.ReactNode }) {
  return <>{children}</>;
}
