import AvaShell from "@/components/shell/AvaShell";

/**
 * AVA007 Cybernetic Console — primary entry point.
 * Replaces the old legacy-redirect dashboard. The three existing cards
 * (Service Request, ESA-Green-Calendar / Green Shield, ESA-Parts-Card) are
 * preserved inside the Viewport and Consoles panels; the Input Ingestion
 * Interface card has been removed per instruction — ingestion now flows
 * through Browser → Parser and Scanner instead of a standalone card.
 */
export default function ConsolePage() {
  return <AvaShell />;
}
