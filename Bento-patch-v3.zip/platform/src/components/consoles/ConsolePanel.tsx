"use client";

import { ServiceRequestCard } from "@/components/esa/ServiceRequestCard";
import { PartsCard } from "@/components/esa/PartsCard";
import { GreenShieldPanel } from "@/components/esa/GreenShieldPanel";
import Link from "next/link";
import { IconArrowRight } from "../shell/icons";

export function EsaMaintenanceConsole() {
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
      <ConsoleHeader title="ESA Maintenance" href="/consoles/esa-maintenance" />
      <div className="bento-grid" style={{ gridTemplateColumns: "1fr" }}>
        <div className="bento-card" style={{ padding: 16 }}>
          <ServiceRequestCard />
        </div>
        <div className="bento-card" style={{ padding: 16 }}>
          <GreenShieldPanel />
        </div>
        <div className="bento-card" style={{ padding: 16 }}>
          <PartsCard />
        </div>
      </div>
    </div>
  );
}

export function HelpAssemblyConsole() {
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
      <ConsoleHeader title="Help Assembly" href="/consoles/help-assembly" />
      <div className="bento-card" style={{ padding: 20, fontSize: 12.5, color: "var(--bento-text-muted)" }}>
        Help Assembly retains its own console at{" "}
        <Link href="/consoles/help-assembly" style={{ color: "var(--bento-accent-blue)" }}>
          /consoles/help-assembly
        </Link>
        . Open it inline once you decide whether it should share this shell&apos;s Bento cards or keep its distinct
        HD Supply-vendored layout.
      </div>
    </div>
  );
}

function ConsoleHeader({ title, href }: { title: string; href: string }) {
  return (
    <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
      <span style={{ fontSize: 13, fontWeight: 600 }}>{title}</span>
      <Link href={href} className="ava-badge" style={{ display: "inline-flex", gap: 6, textDecoration: "none" }}>
        Open full console <IconArrowRight style={{ width: 12, height: 12 }} />
      </Link>
    </div>
  );
}
