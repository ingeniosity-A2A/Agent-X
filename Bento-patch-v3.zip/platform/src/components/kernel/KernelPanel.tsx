"use client";

import { CircularGauge } from "../shell/CircularGauge";

/**
 * Operator/diagnostic surface for the Inferential Kernel (Intellect layer).
 * This screen visualizes kernel state — it is not a separate architectural
 * subsystem. The actual kernel lives in Intellect; this is telemetry.
 *
 * NOTE: the metric cards below stay as "Awaiting telemetry" — no invented
 * numbers. The one gauge that IS live (Execution) is derived from the real
 * boolean stage state already tracked in this component (2 of 3 stages
 * currently flagged active below), not a fabricated confidence score.
 * Wiring real context/inference numbers means exposing a small status
 * endpoint from the Intellect process — same shape this component already
 * expects, so swapping in real data is a fetch away.
 */
const STAGES: { label: string; active: boolean }[] = [
  { label: "reasoning", active: true },
  { label: "validation", active: true },
  { label: "action", active: false },
];

export default function KernelPanel() {
  const activeCount = STAGES.filter((s) => s.active).length;

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
      <div className="bento-card bento-card--elevated" style={{ padding: 18 }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 16 }}>
          <span style={{ fontSize: 13, fontWeight: 600 }}>Inferential Kernel</span>
          <span className="ava-badge">
            <span className="ava-dot" />
            Cognitive state · active
          </span>
        </div>

        <div className="bento-grid" style={{ gridTemplateColumns: "1fr 1fr auto" }}>
          <Metric label="Context" value="Awaiting telemetry" sub="artifacts · evidence nodes · active goals" />
          <Metric label="Inference" value="Awaiting telemetry" sub="model · context window · confidence" />
          <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 6 }}>
            <CircularGauge value={activeCount} max={STAGES.length} label="stages" />
            <span style={{ fontSize: 10, color: "var(--bento-text-muted)" }}>execution stages active</span>
          </div>
        </div>

        <div style={{ marginTop: 16 }}>
          <div style={{ fontSize: 11, textTransform: "uppercase", letterSpacing: "0.08em", color: "var(--bento-text-muted)", marginBottom: 8 }}>
            Execution
          </div>
          <div style={{ display: "flex", gap: 18 }}>
            {STAGES.map((s) => (
              <Stage key={s.label} label={s.label} active={s.active} />
            ))}
          </div>
        </div>

        <div style={{ marginTop: 16 }}>
          <div style={{ fontSize: 11, textTransform: "uppercase", letterSpacing: "0.08em", color: "var(--bento-text-muted)", marginBottom: 8 }}>
            Feedback loop
          </div>
          <div className="bento-card--inset" style={{ borderRadius: 14, padding: "12px 14px", fontSize: 12, display: "flex", flexDirection: "column", gap: 6 }}>
            <div>Exoskeleton → Intellect <span style={{ color: "var(--bento-text-muted)" }}>· clean observation</span></div>
            <div>Intellect → Exoskeleton <span style={{ color: "var(--bento-text-muted)" }}>· intent dispatch</span></div>
          </div>
        </div>
      </div>

      <div className="bento-card" style={{ padding: 16, fontSize: 12, color: "var(--bento-text-muted)", lineHeight: 1.6 }}>
        Zero-Core Passive Interception: Intellect writes an Intent to the shared queue and resumes reasoning; the
        Exoskeleton intercepts, dispatches to the relevant capability (Browser, Lens, Terminals), and returns only a
        clean observation. This panel is the read side of that loop.
      </div>
    </div>
  );
}

function Metric({ label, value, sub }: { label: string; value: string; sub: string }) {
  return (
    <div className="bento-card--inset" style={{ borderRadius: 16, padding: 16 }}>
      <div style={{ fontSize: 11, color: "var(--bento-text-muted)", marginBottom: 6 }}>{label}</div>
      <div style={{ fontSize: 15, fontWeight: 600, marginBottom: 4 }}>{value}</div>
      <div style={{ fontSize: 10.5, color: "var(--bento-text-muted)" }}>{sub}</div>
    </div>
  );
}

function Stage({ label, active }: { label: string; active: boolean }) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 12 }}>
      <span className={`ava-dot ${active ? "" : "off"}`} />
      <span style={{ color: active ? "var(--bento-text-primary)" : "var(--bento-text-muted)" }}>{label}</span>
    </div>
  );
}
