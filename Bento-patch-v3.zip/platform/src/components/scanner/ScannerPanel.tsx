"use client";

import { useRef, useState } from "react";
import { IconScan } from "../shell/icons";

export default function ScannerPanel() {
  const [files, setFiles] = useState<File[]>([]);
  const [dragOver, setDragOver] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const addFiles = (list: FileList | null) => {
    if (!list) return;
    setFiles((f) => [...f, ...Array.from(list)]);
  };

  return (
    <div className="bento-card bento-card--elevated" style={{ padding: 18 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 14 }}>
        <IconScan style={{ width: 16, height: 16, opacity: 0.7 }} />
        <span style={{ fontSize: 13, fontWeight: 600 }}>Document Scanner</span>
      </div>

      <div
        onDragOver={(e) => {
          e.preventDefault();
          setDragOver(true);
        }}
        onDragLeave={() => setDragOver(false)}
        onDrop={(e) => {
          e.preventDefault();
          setDragOver(false);
          addFiles(e.dataTransfer.files);
        }}
        onClick={() => inputRef.current?.click()}
        className="bento-card--inset"
        style={{
          borderRadius: 20,
          borderStyle: "dashed",
          borderWidth: 1.5,
          borderColor: dragOver ? "var(--bento-accent-blue)" : "rgba(255,255,255,0.1)",
          padding: 40,
          textAlign: "center",
          cursor: "pointer",
          transition: "border-color .15s ease",
        }}
      >
        <div style={{ fontSize: 13, color: "var(--bento-text-secondary)", marginBottom: 4 }}>
          Drop files, or click to browse
        </div>
        <div style={{ fontSize: 11, color: "var(--bento-text-muted)" }}>PDF · Image · DOCX · TXT · ZIP</div>
        <input
          ref={inputRef}
          type="file"
          multiple
          hidden
          onChange={(e) => addFiles(e.target.files)}
        />
      </div>

      {files.length > 0 && (
        <div style={{ marginTop: 16, display: "flex", flexDirection: "column", gap: 6 }}>
          {files.map((f, i) => (
            <div key={i} className="bento-card--inset" style={{ borderRadius: 10, padding: "8px 12px", display: "flex", justifyContent: "space-between", fontSize: 12 }}>
              <span className="mono">{f.name}</span>
              <span style={{ color: "var(--bento-text-muted)" }}>{(f.size / 1024).toFixed(1)} KB · queued</span>
            </div>
          ))}
          <div style={{ fontSize: 10.5, color: "var(--bento-text-muted)", marginTop: 6, lineHeight: 1.5 }}>
            Queued files are ready for the ingestion pipeline (Parser → Chunk → MemBrain). Wire this to your
            ingestion API route to actually process them — the upload/selection surface above is fully working.
          </div>
        </div>
      )}
    </div>
  );
}
