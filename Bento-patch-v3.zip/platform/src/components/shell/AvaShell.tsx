"use client";

import { useState } from "react";
import LeftNav from "./LeftNav";
import BottomAIBar from "./BottomAIBar";
import BrowserPanel from "../browser/BrowserPanel";
import Viewport from "../viewport/Viewport";
import KernelPanel from "../kernel/KernelPanel";
import WorkflowPanel from "../workflow/WorkflowPanel";
import TerminalPanel from "../terminals/TerminalPanel";
import ProductLensPanel from "../lens/ProductLensPanel";
import ScannerPanel from "../scanner/ScannerPanel";
import { BenchmarksPanel, IntelligenceInjectionPanel } from "../dev/DevPanels";
import { EsaMaintenanceConsole, HelpAssemblyConsole } from "../consoles/ConsolePanel";
import { IntellectPanel, SettingsPanel } from "./OverviewPanels";

export type SectionId =
  | "intellect"
  | "browser"
  | "viewport"
  | "lens"
  | "scanner"
  | "workflow"
  | "kernel"
  | "term-bash"
  | "term-linux"
  | "term-termux"
  | "console-help-assembly"
  | "console-esa"
  | "dev-benchmarks"
  | "dev-injection"
  | "settings";

const TITLES: Record<SectionId, { title: string; sub: string }> = {
  intellect: { title: "Intellect", sub: "Cognitive core overview" },
  browser: { title: "Browser", sub: "agent-browser · Chrome / CDP" },
  viewport: { title: "Viewport", sub: "React cards · Three.js · GSAP" },
  lens: { title: "Product Lens", sub: "Camera → identification → ingestion" },
  scanner: { title: "Scanner", sub: "Document upload → ingestion" },
  workflow: { title: "Workflow", sub: "Exoskeleton → Intellect pipeline" },
  kernel: { title: "Inferential Kernel", sub: "Diagnostic / operator surface" },
  "term-bash": { title: "Bash", sub: "Exoskeleton exec context" },
  "term-linux": { title: "Linux", sub: "Host execution context" },
  "term-termux": { title: "Termux", sub: "S26 Ultra exec context" },
  "console-help-assembly": { title: "Help Assembly", sub: "HD Supply-vendored console" },
  "console-esa": { title: "ESA Maintenance", sub: "Service · Parts · Green Shield" },
  "dev-benchmarks": { title: "Benchmarks", sub: "Capability substrate comparison" },
  "dev-injection": { title: "Intelligence Injection", sub: "Curated source → MemBrain" },
  settings: { title: "System", sub: "Capability wiring status" },
};

export default function AvaShell() {
  const [active, setActive] = useState<SectionId>("browser");
  const { title, sub } = TITLES[active];

  return (
    <div className="ava-shell">
      <div className="ava-grid">
        <LeftNav active={active} onSelect={setActive} />

        <div style={{ display: "flex", flexDirection: "column", minWidth: 0 }}>
          <div className="ava-topbar">
            <div>
              <h1>{title}</h1>
              <p>{sub}</p>
            </div>
            <span className="ava-badge">
              <span className="ava-dot" />
              Exoskeleton online
            </span>
          </div>

          <div className="ava-workspace ava-scrollbar">
            {active === "intellect" && <IntellectPanel />}
            {active === "browser" && <BrowserPanel />}
            {active === "viewport" && <Viewport />}
            {active === "lens" && <ProductLensPanel />}
            {active === "scanner" && <ScannerPanel />}
            {active === "workflow" && <WorkflowPanel />}
            {active === "kernel" && <KernelPanel />}
            {active === "term-bash" && <TerminalPanel context="bash" />}
            {active === "term-linux" && <TerminalPanel context="linux" />}
            {active === "term-termux" && <TerminalPanel context="termux" />}
            {active === "console-help-assembly" && <HelpAssemblyConsole />}
            {active === "console-esa" && <EsaMaintenanceConsole />}
            {active === "dev-benchmarks" && <BenchmarksPanel />}
            {active === "dev-injection" && <IntelligenceInjectionPanel />}
            {active === "settings" && <SettingsPanel />}
          </div>
        </div>
      </div>

      <div className="ava-bottombar-wrap" style={{ position: "fixed", bottom: 0, left: 248, right: 0 }}>
        <BottomAIBar activeSection={active} />
      </div>
    </div>
  );
}
