"use client";

import { useState } from "react";
import { IconMic, IconPaperclip, IconSend } from "./icons";
import { Waveform } from "./Waveform";
import type { SectionId } from "./AvaShell";

/**
 * Bottom AI communication interface. Sends `current_surface` (derived from
 * the active nav section) alongside the message so Ava's intent resolution
 * knows what the user is looking at — e.g. "extract the maintenance
 * procedures" while on the Browser panel carries current_surface: "browser".
 *
 * The mic toggle here drives a real UI state (`listening`) and the waveform
 * animates off that real state — it is not simulating audio input that
 * doesn't exist. Actual STT capture (getUserMedia + a speech service) is
 * the next-phase item; this is the honest UI half of that wiring.
 */
export default function BottomAIBar({ activeSection }: { activeSection: SectionId }) {
  const [value, setValue] = useState("");
  const [listening, setListening] = useState(false);

  const send = () => {
    if (!value.trim()) return;
    // Intent dispatch point: POST { text: value, current_surface: activeSection }
    // to the Intellect intent queue once that endpoint exists.
    setValue("");
  };

  return (
    <div className="ava-bottombar">
      <button className="ava-icon-btn" title="Attach">
        <IconPaperclip />
      </button>
      <span className="ava-context-chip">{activeSection}</span>
      {listening ? (
        <Waveform isActive />
      ) : (
        <input
          placeholder="Ask Ava…"
          value={value}
          onChange={(e) => setValue(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && send()}
        />
      )}
      <button
        className={`ava-icon-btn ${listening ? "listening" : ""}`}
        title={listening ? "Stop listening" : "Voice"}
        onClick={() => setListening((v) => !v)}
      >
        <IconMic />
      </button>
      <button className="ava-icon-btn primary" title="Send" onClick={send}>
        <IconSend />
      </button>
    </div>
  );
}
