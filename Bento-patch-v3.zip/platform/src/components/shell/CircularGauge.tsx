"use client";

export function CircularGauge({
  value,
  max,
  label,
}: {
  value: number;
  max: number;
  label: string;
}) {
  const radius = 70;
  const circumference = 2 * Math.PI * radius;
  const progress = (Math.max(0, Math.min(value, max)) / max) * circumference;

  return (
    <div className="relative flex items-center justify-center" style={{ width: 176, height: 176 }}>
      <svg
        style={{ position: "absolute", inset: 0, width: "100%", height: "100%", transform: "rotate(-90deg)" }}
      >
        <defs>
          <linearGradient id="gaugeGradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#3b82f6" />
            <stop offset="50%" stopColor="#8b5cf6" />
            <stop offset="100%" stopColor="#f97316" />
          </linearGradient>
        </defs>
        <circle cx="50%" cy="50%" r={radius} fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth="12" />
        <circle
          cx="50%"
          cy="50%"
          r={radius}
          fill="none"
          stroke="url(#gaugeGradient)"
          strokeWidth="12"
          strokeLinecap="round"
          strokeDasharray={circumference}
          strokeDashoffset={circumference - progress}
          style={{ transition: "stroke-dashoffset 0.8s ease" }}
        />
      </svg>

      <div
        style={{
          width: 128,
          height: 128,
          borderRadius: "50%",
          background: "var(--bento-bg-elevated)",
          boxShadow: "var(--bento-shadow-dark-inset)",
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        <span style={{ fontSize: 26, fontWeight: 700, color: "var(--bento-text-primary)" }}>
          {value}/{max}
        </span>
        <span style={{ fontSize: 10, color: "var(--bento-text-muted)", textTransform: "uppercase", letterSpacing: "0.08em" }}>
          {label}
        </span>
      </div>
    </div>
  );
}
