"use client";

import { useState } from "react";
import { useDevSlideOut } from "./gsap-hooks";

function IconLockClosed(p: React.SVGProps<SVGSVGElement>) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" {...p}>
      <rect x="5" y="10" width="14" height="10" rx="2" />
      <path d="M8 10V7a4 4 0 0 1 8 0v3" />
    </svg>
  );
}
function IconLockOpen(p: React.SVGProps<SVGSVGElement>) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" {...p}>
      <rect x="5" y="10" width="14" height="10" rx="2" />
      <path d="M8 10V7a4 4 0 0 1 7.5-2" />
    </svg>
  );
}

/**
 * Inverted-Corner DEV lock card (updated master doc §2.3/§3). The trigger
 * toggles real state; the slide-out panel is driven by the real
 * useDevSlideOut GSAP hook, not a CSS-only fake. `children` is the DEV
 * surface that gets revealed — pass your real content in.
 */
export function DevFeatureCard({
  title = "DEV Capabilities",
  subtitle = "Unlock to expand inline",
  children,
}: {
  title?: string;
  subtitle?: string;
  children?: React.ReactNode;
}) {
  const [isLocked, setIsLocked] = useState(true);
  const panelRef = useDevSlideOut(isLocked);

  return (
    <div className="bento-card bento-card-inverted-corner" style={{ position: "relative", padding: 18 }}>
      <button
        onClick={() => setIsLocked((v) => !v)}
        className="exploded-lock-trigger"
        title={isLocked ? "Unlock additional content" : "Lock content"}
      >
        {isLocked ? <IconLockClosed style={{ width: 14, height: 14 }} /> : <IconLockOpen style={{ width: 14, height: 14 }} />}
      </button>

      <div style={{ paddingRight: 32 }}>
        <h4 style={{ fontSize: 13, fontWeight: 600, marginBottom: 2 }}>{title}</h4>
        <p style={{ fontSize: 11, color: "var(--bento-text-muted)" }}>{isLocked ? subtitle : "Unlocked"}</p>
      </div>

      {!isLocked && (
        <div ref={panelRef} className="dev-slideout-panel" style={{ marginTop: 14 }}>
          {children}
        </div>
      )}
    </div>
  );
}
