"use client";

import { useState } from "react";
import { IconCamera } from "./icons";

export interface FurnitureCard4Props {
  isGlassTinted?: boolean;
  title?: string;
  items?: string[];
  children?: React.ReactNode;
}

/**
 * Furniture Card 4 — standard bento card footprint with an internal scroll
 * selector docked along the far-right inside edge of the viewport (per the
 * updated master doc §2.1). Content in the main viewport slot is whatever
 * `children` renders (render target for a real product/3D preview);
 * the wheel items are placeholder catalog entries until wired to a real
 * catalog/render source.
 */
export function FurnitureCard4({ isGlassTinted = false, title = "Furniture Design", items, children }: FurnitureCard4Props) {
  const list = items ?? ["Quote 1", "Quote 2", "Item A", "Item B", "Item C"];
  const [selected, setSelected] = useState(0);

  return (
    <div className={`bento-card ${isGlassTinted ? "bento-card-glass-tinted" : ""}`} style={{ padding: 18 }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 14 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <span style={{ width: 8, height: 8, borderRadius: "50%", background: "var(--bento-accent-mint)", boxShadow: "0 0 8px var(--bento-accent-mint)" }} />
          <span style={{ fontSize: 13, fontWeight: 600 }}>{title}</span>
        </div>
        <button className="ava-icon-btn" title="Lens capture">
          <IconCamera />
        </button>
      </div>

      <div className="furniture-viewport">
        <div style={{ flex: 1, height: "100%", display: "flex", alignItems: "center", justifyContent: "center" }}>
          {children ?? (
            <span style={{ fontSize: 11.5, color: "var(--bento-text-muted)", textAlign: "center", maxWidth: 200 }}>
              Render target — wire this slot to the real 3D/product preview source when ready.
            </span>
          )}
        </div>

        <div className="furniture-scroll-wheel no-scrollbar">
          {list.map((item, idx) => (
            <div
              key={item}
              onClick={() => setSelected(idx)}
              className={`furniture-wheel-item ${selected === idx ? "selected" : ""}`}
              title={item}
            >
              {idx + 1}
            </div>
          ))}
        </div>
      </div>

      <div style={{ marginTop: 10, fontSize: 11, color: "var(--bento-text-muted)" }}>{list[selected]}</div>
    </div>
  );
}
