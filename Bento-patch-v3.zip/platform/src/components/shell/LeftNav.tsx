"use client";

import {
  IconBrain,
  IconGlobe,
  IconCube,
  IconCamera,
  IconScan,
  IconWorkflow,
  IconKernel,
  IconTerminal,
  IconLinux,
  IconPhone,
  IconWrench,
  IconLeaf,
  IconGauge,
  IconInjection,
  IconSettings,
} from "./icons";
import type { SectionId } from "./AvaShell";

const PRIMARY: { id: SectionId; label: string; icon: (p: React.SVGProps<SVGSVGElement>) => React.ReactElement }[] = [
  { id: "intellect", label: "Intellect", icon: IconBrain },
  { id: "browser", label: "Browser", icon: IconGlobe },
  { id: "viewport", label: "Viewport", icon: IconCube },
  { id: "lens", label: "Product Lens", icon: IconCamera },
  { id: "scanner", label: "Scanner", icon: IconScan },
  { id: "workflow", label: "Workflow", icon: IconWorkflow },
  { id: "kernel", label: "Kernel", icon: IconKernel },
];

const TERMINALS: { id: SectionId; label: string; icon: (p: React.SVGProps<SVGSVGElement>) => React.ReactElement }[] = [
  { id: "term-bash", label: "Bash", icon: IconTerminal },
  { id: "term-linux", label: "Linux", icon: IconLinux },
  { id: "term-termux", label: "Termux", icon: IconPhone },
];

const CONSOLES: { id: SectionId; label: string; icon: (p: React.SVGProps<SVGSVGElement>) => React.ReactElement }[] = [
  { id: "console-help-assembly", label: "Help Assembly", icon: IconWrench },
  { id: "console-esa", label: "ESA Maintenance", icon: IconLeaf },
];

const DEV: { id: SectionId; label: string; icon: (p: React.SVGProps<SVGSVGElement>) => React.ReactElement }[] = [
  { id: "dev-benchmarks", label: "Benchmarks", icon: IconGauge },
  { id: "dev-injection", label: "Intelligence Injection", icon: IconInjection },
];

function NavGroup({
  label,
  items,
  active,
  onSelect,
}: {
  label: string;
  items: typeof PRIMARY;
  active: SectionId;
  onSelect: (id: SectionId) => void;
}) {
  return (
    <>
      <div className="ava-nav-section-label">{label}</div>
      {items.map((item) => (
        <button
          key={item.id}
          className={`ava-nav-item ${active === item.id ? "active" : ""}`}
          onClick={() => onSelect(item.id)}
        >
          <item.icon />
          <span>{item.label}</span>
        </button>
      ))}
    </>
  );
}

export default function LeftNav({
  active,
  onSelect,
}: {
  active: SectionId;
  onSelect: (id: SectionId) => void;
}) {
  return (
    <nav className="ava-nav ava-scrollbar">
      <div className="ava-nav-brand">
        <div className="ava-nav-mark">A7</div>
        <div>
          <div className="ava-nav-title">AVA007</div>
          <div className="ava-nav-sub">Cybernetic Console</div>
        </div>
      </div>

      <div className="ava-nav-section-label" style={{ paddingTop: 4 }}>
        Core
      </div>
      {PRIMARY.map((item) => (
        <button
          key={item.id}
          className={`ava-nav-item ${active === item.id ? "active" : ""}`}
          onClick={() => onSelect(item.id)}
        >
          <item.icon />
          <span>{item.label}</span>
        </button>
      ))}

      <NavGroup label="Terminals" items={TERMINALS} active={active} onSelect={onSelect} />
      <NavGroup label="Consoles" items={CONSOLES} active={active} onSelect={onSelect} />
      <NavGroup label="Dev" items={DEV} active={active} onSelect={onSelect} />

      <div style={{ flex: 1 }} />
      <button
        className={`ava-nav-item ${active === "settings" ? "active" : ""}`}
        onClick={() => onSelect("settings")}
      >
        <IconSettings />
        <span>System</span>
      </button>
    </nav>
  );
}
