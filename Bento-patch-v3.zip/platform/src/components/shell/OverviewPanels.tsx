"use client";

import { useBentoReveal, useTilt3D } from "./gsap-hooks";

export function IntellectPanel() {
  const revealRef = useBentoReveal(".stat-card");
  return (
    <div ref={revealRef} className="bento-grid" style={{ gridTemplateColumns: "repeat(3, 1fr)" }}>
      <StatCard label="Active goals" value="—" />
      <StatCard label="Evidence nodes" value="—" />
      <StatCard label="Artifacts in context" value="—" />
      <div className="bento-card" style={{ padding: 18, gridColumn: "span 3" }}>
        <div style={{ fontSize: 13, fontWeight: 600, marginBottom: 8 }}>Intellect</div>
        <div style={{ fontSize: 12.5, color: "var(--bento-text-muted)", lineHeight: 1.6 }}>
          Intellect owns the Inferential Kernel — context, evidence, inference, and validation. The Exoskeleton
          (Browser, Viewport, Product Lens, Scanner, Terminals) executes capabilities on Intellect&apos;s behalf and
          returns clean observations. This shell is the control surface over both; it is not itself the kernel. See
          the Kernel tab for the live diagnostic view.
        </div>
      </div>
    </div>
  );
}

export function SettingsPanel() {
  return (
    <div className="bento-card" style={{ padding: 18 }}>
      <div style={{ fontSize: 13, fontWeight: 600, marginBottom: 12 }}>System</div>
      <Row label="Browser capability" value="agent-browser (CDP)" />
      <Row label="Terminal capability" value="exec (single-shot) — PTY upgrade pending" />
      <Row label="Audio service" value="not wired — mic/TTS UI present, backend pending" />
      <Row label="Deploy targets" value="Vercel (frontend) · Render (agent API) · Cloudflare (DNS/edge)" />
    </div>
  );
}

function StatCard({ label, value }: { label: string; value: string }) {
  const { cardRef, handleMouseMove, handleMouseLeave } = useTilt3D(8);
  return (
    <div
      ref={cardRef}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      className="bento-card bento-card--inset stat-card bento-tilt"
      style={{ borderRadius: 16, padding: 16 }}
    >
      <div style={{ fontSize: 11, color: "var(--bento-text-muted)", marginBottom: 6 }}>{label}</div>
      <div style={{ fontSize: 18, fontWeight: 600 }}>{value}</div>
    </div>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div style={{ display: "flex", justifyContent: "space-between", padding: "10px 0", borderBottom: "1px solid rgba(255,255,255,0.06)", fontSize: 12.5 }}>
      <span style={{ color: "var(--bento-text-muted)" }}>{label}</span>
      <span className="mono">{value}</span>
    </div>
  );
}
