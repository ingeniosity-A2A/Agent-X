"use client";

import { useState } from "react";
import { Waveform } from "./Waveform";

/**
 * Universal Feature Stack (per updated master doc §2.2) — the shared audio
 * module used anywhere in the shell that needs voice: bottom AI bar,
 * Product Lens voice notes, Browser "AI" tab, etc. All controls here are
 * real controlled state — toggling "playing" really drives the Waveform,
 * the select really switches source, the prompt really captures text.
 * What's NOT wired yet: an actual audio backend (TTS/stream/library
 * playback) and the prompt's dispatch target — both marked below.
 */
export function UniversalFeatureStack({ showPrompt = false }: { showPrompt?: boolean }) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [audioSource, setAudioSource] = useState<"stream" | "prerecorded">("stream");
  const [prompt, setPrompt] = useState("");

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
      <div style={{ display: "flex", justifyContent: "center", padding: "6px 0" }}>
        <Waveform bars={32} isActive={isPlaying} />
      </div>

      <div
        className="bento-card--inset"
        style={{ borderRadius: 14, padding: "8px 10px", display: "flex", alignItems: "center", justifyContent: "space-between", gap: 8 }}
      >
        <button
          onClick={() => setIsPlaying((v) => !v)}
          className="ava-badge"
          style={{ cursor: "pointer", border: "1px solid rgba(59,130,246,0.3)", background: "rgba(59,130,246,0.15)", color: "#93c5fd" }}
        >
          <span className={`ava-dot ${isPlaying ? "" : "off"}`} />
          {audioSource === "stream" ? (isPlaying ? "Streaming…" : "Stream Voice") : isPlaying ? "Playing…" : "Play Recorded"}
        </button>

        <select
          value={audioSource}
          onChange={(e) => setAudioSource(e.target.value as "stream" | "prerecorded")}
          style={{
            background: "transparent",
            fontSize: 11.5,
            color: "var(--bento-text-secondary)",
            border: "1px solid rgba(255,255,255,0.1)",
            borderRadius: 8,
            padding: "4px 8px",
          }}
        >
          <option value="stream" style={{ background: "#111118" }}>
            Live Stream
          </option>
          <option value="prerecorded" style={{ background: "#111118" }}>
            Audio Library Item
          </option>
        </select>
      </div>

      {showPrompt && (
        <div className="bento-card--inset" style={{ borderRadius: 14, padding: "8px 10px" }}>
          <input
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="Type UI prompt…"
            className="mono"
            style={{ width: "100%", background: "transparent", border: "none", outline: "none", color: "var(--bento-text-primary)", fontSize: 11.5 }}
          />
        </div>
      )}

      <div style={{ fontSize: 10, color: "var(--bento-text-muted)", lineHeight: 1.5 }}>
        Play/source/prompt state above is real UI state — no audio backend is wired yet, so pressing play toggles
        the waveform only. Connect a TTS/stream endpoint here to make it produce sound.
      </div>
    </div>
  );
}
