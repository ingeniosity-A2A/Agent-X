"use client";

import { useEffect, useRef } from "react";
import gsap from "gsap";

export function Waveform({ bars = 32, isActive = false }: { bars?: number; isActive?: boolean }) {
  const barsRef = useRef<(HTMLDivElement | null)[]>([]);
  const tlRef = useRef<gsap.core.Timeline | null>(null);

  useEffect(() => {
    const els = barsRef.current.filter(Boolean) as HTMLDivElement[];
    if (els.length === 0) return;

    if (!isActive) {
      tlRef.current?.kill();
      gsap.to(els, { scaleY: 0.15, duration: 0.4, ease: "power2.out" });
      return;
    }

    const tl = gsap.timeline({ repeat: -1 });
    els.forEach((bar, i) => {
      tl.to(
        bar,
        {
          scaleY: 0.2 + Math.random() * 0.8,
          duration: 0.3 + Math.random() * 0.2,
          ease: "sine.inOut",
        },
        i * 0.02,
      );
    });
    tlRef.current = tl;

    return () => {
      tl.kill();
    };
  }, [isActive]);

  return (
    <div style={{ display: "flex", alignItems: "flex-end", justifyContent: "center", gap: 2, height: 28, width: 90 }}>
      {Array.from({ length: bars }).map((_, i) => (
        <div
          key={i}
          ref={(el) => {
            barsRef.current[i] = el;
          }}
          style={{
            width: 2,
            height: "100%",
            borderRadius: 2,
            background: "linear-gradient(to top, #7dd4a8, #f7d97a)",
            transformOrigin: "bottom",
            transform: "scaleY(0.15)",
          }}
        />
      ))}
    </div>
  );
}
