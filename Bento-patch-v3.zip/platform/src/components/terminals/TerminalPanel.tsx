"use client";

import { useState, useRef, useEffect } from "react";

type Line = { kind: "cmd" | "out" | "err" | "sys"; text: string };

export default function TerminalPanel({ context }: { context: "bash" | "linux" | "termux" }) {
  const [history, setHistory] = useState<Line[]>([
    { kind: "sys", text: `${context} exec — connected to server process (see /api/terminal/exec)` },
  ]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight });
  }, [history]);

  const runCommand = async () => {
    const cmd = input.trim();
    if (!cmd || busy) return;
    setHistory((h) => [...h, { kind: "cmd", text: cmd }]);
    setInput("");
    setBusy(true);
    try {
      const res = await fetch("/api/terminal/exec", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ command: cmd, context }),
      });
      const data = await res.json();
      setHistory((h) => [
        ...h,
        ...(data.stdout ? [{ kind: "out" as const, text: data.stdout.replace(/\n$/, "") }] : []),
        ...(data.stderr ? [{ kind: "err" as const, text: data.stderr.replace(/\n$/, "") }] : []),
        ...(!data.ok && !data.stderr ? [{ kind: "err" as const, text: data.error || "command failed" }] : []),
      ]);
    } catch {
      setHistory((h) => [...h, { kind: "err", text: "Could not reach /api/terminal/exec" }]);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="bento-card bento-card--elevated" style={{ padding: 14 }}>
      <div style={{ fontSize: 11, color: "var(--bento-text-muted)", marginBottom: 10 }}>
        Single-shot exec surface — real server execution, not yet a persistent PTY (no vim/htop, no shell state
        between commands beyond cwd). Full PTY streaming is the next-phase upgrade for this tab.
      </div>
      <div
        ref={scrollRef}
        className="mono bento-card--inset ava-scrollbar"
        style={{ borderRadius: 14, padding: 14, height: 320, overflowY: "auto", fontSize: 12.5, lineHeight: 1.6 }}
      >
        {history.map((line, i) => (
          <div
            key={i}
            style={{
              color:
                line.kind === "cmd"
                  ? "var(--bento-accent-mint)"
                  : line.kind === "err"
                  ? "var(--bento-accent-coral)"
                  : line.kind === "sys"
                  ? "var(--bento-text-muted)"
                  : "var(--bento-text-secondary)",
              whiteSpace: "pre-wrap",
            }}
          >
            {line.kind === "cmd" ? `${context}$ ${line.text}` : line.text}
          </div>
        ))}
        {busy && <div style={{ color: "var(--bento-text-muted)" }}>…</div>}
      </div>
      <div style={{ display: "flex", gap: 8, marginTop: 10 }}>
        <span className="mono" style={{ color: "var(--bento-accent-mint)", fontSize: 12.5, alignSelf: "center" }}>
          {context}$
        </span>
        <input
          className="mono"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && runCommand()}
          placeholder="run a command…"
          style={{
            flex: 1,
            background: "var(--bento-surface-dark)",
            border: "1px solid rgba(255,255,255,0.08)",
            borderRadius: 10,
            padding: "8px 12px",
            color: "var(--bento-text-primary)",
            fontSize: 12.5,
            outline: "none",
          }}
        />
      </div>
    </div>
  );
}
