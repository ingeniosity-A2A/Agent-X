"use client";

import { useState } from "react";
import { ServiceRequestCard } from "@/components/esa/ServiceRequestCard";
import { PartsCard } from "@/components/esa/PartsCard";
import { GreenShieldPanel } from "@/components/esa/GreenShieldPanel";
import { IconCube } from "../shell/icons";
import { useBentoReveal, useTilt3D } from "../shell/gsap-hooks";
import { FurnitureCard4 } from "../shell/FurnitureCard4";

/**
 * Card registry — this is the render.card / render.scene target described
 * in the AVA007 spec: an A2UI intent like `render.card:service-request`
 * resolves here instead of navigating to a new route.
 *
 * "Input Ingestion Interface" card intentionally removed per instruction —
 * ingestion now happens through Browser → Parser and Scanner, not a
 * standalone dashboard card.
 */
const CARD_REGISTRY: { id: string; label: string; render: () => React.ReactElement }[] = [
  { id: "service-request", label: "Service Request", render: () => <ServiceRequestCard /> },
  { id: "esa-green-calendar", label: "ESA-Green-Calendar", render: () => <GreenShieldPanel /> },
  { id: "esa-parts-card", label: "ESA-Parts-Card", render: () => <PartsCard /> },
  { id: "furniture-4", label: "Furniture Design", render: () => <FurnitureCard4 isGlassTinted /> },
];

export default function Viewport() {
  const [activeCard, setActiveCard] = useState(CARD_REGISTRY[0].id);
  const [gsapActive] = useState(true);
  const revealRef = useBentoReveal(".data-layer-card");

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
      {/* rendering canvas */}
      <div className="bento-card bento-card--elevated" style={{ padding: 14 }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 10 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <IconCube style={{ width: 16, height: 16, opacity: 0.7 }} />
            <span style={{ fontSize: 13, fontWeight: 600 }}>Viewport</span>
          </div>
          <span className="ava-badge">
            <span className={`ava-dot ${gsapActive ? "" : "off"}`} />
            GSAP {gsapActive ? "active" : "idle"}
          </span>
        </div>

        <div className="bento-tabs" style={{ marginBottom: 12 }}>
          {CARD_REGISTRY.map((c) => (
            <button
              key={c.id}
              className={`bento-tab ${activeCard === c.id ? "active" : ""}`}
              onClick={() => setActiveCard(c.id)}
            >
              {c.label}
            </button>
          ))}
        </div>

        <div
          className="bento-card--inset"
          style={{ borderRadius: 20, padding: 18, minHeight: 420, display: "flex", justifyContent: "center" }}
        >
          <div style={{ width: "100%", maxWidth: 720 }}>{CARD_REGISTRY.find((c) => c.id === activeCard)?.render()}</div>
        </div>
      </div>

      {/* three-layer data model strip — GSAP scroll reveal + tilt per master doc §3.1/§3.3 */}
      <div ref={revealRef} className="bento-grid" style={{ gridTemplateColumns: "repeat(3, 1fr)" }}>
        <DataLayerCard title="Service Repair Request" desc="Work order state — feeds ESA Maintenance dispatch." accent="var(--bento-accent-blue)" />
        <DataLayerCard title="Parts Used" desc="Feeds back to Ava007 inventory & reorder logic." accent="var(--bento-accent-mint)" />
        <DataLayerCard title="Spatial Room State" desc="Hologram floor plan as spatial index." accent="var(--bento-accent-purple)" />
      </div>
    </div>
  );
}

function DataLayerCard({ title, desc, accent }: { title: string; desc: string; accent: string }) {
  const { cardRef, handleMouseMove, handleMouseLeave } = useTilt3D(10);
  return (
    <div
      ref={cardRef}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      className="bento-card data-layer-card bento-tilt"
      style={{ padding: 16, gridColumn: "span 1" }}
    >
      <div style={{ width: 8, height: 8, borderRadius: "50%", background: accent, marginBottom: 10, boxShadow: `0 0 8px ${accent}` }} />
      <div style={{ fontSize: 12.5, fontWeight: 600, marginBottom: 4 }}>{title}</div>
      <div style={{ fontSize: 11.5, color: "var(--bento-text-muted)", lineHeight: 1.5 }}>{desc}</div>
    </div>
  );
}
