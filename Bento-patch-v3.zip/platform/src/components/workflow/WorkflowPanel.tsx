"use client";

const STEPS = [
  { label: "Browser", detail: "agent-browser session, live page" },
  { label: "Download / Read", detail: "artifact or extracted text" },
  { label: "Document Parser", detail: "MIME detect → extraction / OCR" },
  { label: "Chunk / Extract", detail: "structure + metadata" },
  { label: "MemBrain", detail: "embeddings / graph" },
  { label: "Inferential Kernel", detail: "context + evidence + inference" },
  { label: "Intelligence", detail: "curated, validated output" },
];

export default function WorkflowPanel() {
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
      <div className="bento-card bento-card--elevated" style={{ padding: 18 }}>
        <div style={{ fontSize: 13, fontWeight: 600, marginBottom: 4 }}>Ingestion Workflow</div>
        <div style={{ fontSize: 12, color: "var(--bento-text-muted)", marginBottom: 18 }}>
          The bridge between Exoskeleton capabilities and Intellect. Every artifact — a browsed page, a downloaded
          PDF, a Lens capture, a Scanner upload — flows through this same pipeline before it becomes usable memory.
        </div>

        <div style={{ display: "flex", flexDirection: "column", gap: 0 }}>
          {STEPS.map((step, i) => (
            <div key={step.label} style={{ display: "flex", gap: 14 }}>
              <div style={{ display: "flex", flexDirection: "column", alignItems: "center" }}>
                <div
                  style={{
                    width: 10,
                    height: 10,
                    borderRadius: "50%",
                    background: "var(--bento-gradient-cool)",
                    boxShadow: "0 0 10px rgba(139,92,246,0.5)",
                    flexShrink: 0,
                  }}
                />
                {i < STEPS.length - 1 && <div style={{ width: 1.5, flex: 1, minHeight: 28, background: "rgba(255,255,255,0.1)" }} />}
              </div>
              <div style={{ paddingBottom: 20 }}>
                <div style={{ fontSize: 13, fontWeight: 600 }}>{step.label}</div>
                <div style={{ fontSize: 11.5, color: "var(--bento-text-muted)" }}>{step.detail}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
