/**
 * AVA007 Exoskeleton — Agent Browser capability wrapper
 * ------------------------------------------------------
 * Thin server-side wrapper around the real `agent-browser` Rust CLI
 * (https://github.com/vercel-labs/agent-browser). This is the actual
 * automation substrate for the Browser panel — not a mock.
 *
 * Architecture note: this file lives in the Exoskeleton layer. It never
 * makes reasoning decisions — it only executes commands handed to it and
 * returns clean, structured observations. Intent -> here -> CDP -> Chrome.
 *
 * REQUIREMENTS (host machine / deploy target, not this sandbox):
 *   npm install -g agent-browser && agent-browser install
 *   (or) brew install agent-browser && agent-browser install
 *   (or) cargo install agent-browser && agent-browser install
 * See: https://agent-browser.dev/installation
 *
 * Each browser "session" maps 1:1 to an agent-browser --session-name,
 * giving isolated cookies/auth/tabs per AVA007 console session so the
 * ESA Maintenance console and Help Assembly console never cross-contaminate
 * browser state.
 */

import { execFile } from "node:child_process";
import { promisify } from "node:util";

const execFileAsync = promisify(execFile);

const BIN = process.env.AGENT_BROWSER_BIN || "agent-browser";
const DEFAULT_TIMEOUT_MS = 20_000;

export interface BrowserCommandResult {
  ok: boolean;
  stdout: string;
  stderr: string;
  code: number | null;
  command: string[];
}

export interface BrowserSessionOptions {
  session: string;
  headless?: boolean;
  cdpPort?: number;
  profile?: string;
}

function sessionArgs(session: string): string[] {
  return ["--session-name", session];
}

async function run(
  args: string[],
  { timeoutMs = DEFAULT_TIMEOUT_MS }: { timeoutMs?: number } = {},
): Promise<BrowserCommandResult> {
  try {
    const { stdout, stderr } = await execFileAsync(BIN, args, {
      timeout: timeoutMs,
      maxBuffer: 1024 * 1024 * 32, // 32MB — screenshots can be chunky as base64
    });
    return { ok: true, stdout, stderr, code: 0, command: [BIN, ...args] };
  } catch (err: unknown) {
    const e = err as { stdout?: string; stderr?: string; code?: number; message?: string };
    return {
      ok: false,
      stdout: e.stdout ?? "",
      stderr: e.stderr ?? e.message ?? "unknown agent-browser error",
      code: e.code ?? null,
      command: [BIN, ...args],
    };
  }
}

/** Launch (or reuse) an isolated browser session and optionally navigate. */
export async function openSession(opts: BrowserSessionOptions & { url?: string }) {
  const args = [
    "open",
    ...(opts.url ? [opts.url] : []),
    ...sessionArgs(opts.session),
    ...(opts.headless === false ? ["--headed"] : []),
    ...(opts.cdpPort ? ["--cdp", String(opts.cdpPort)] : []),
    ...(opts.profile ? ["--profile", opts.profile] : []),
    "--json",
  ];
  return run(args);
}

/** Full or interactive-only accessibility tree snapshot with @eN refs. */
export async function snapshot(
  session: string,
  opts: { interactive?: boolean; compact?: boolean; depth?: number; selector?: string } = {},
) {
  const args = [
    "snapshot",
    ...sessionArgs(session),
    ...(opts.interactive ? ["-i"] : []),
    ...(opts.compact ? ["-c"] : []),
    ...(opts.depth ? ["-d", String(opts.depth)] : []),
    ...(opts.selector ? ["-s", opts.selector] : []),
    "--json",
  ];
  return run(args);
}

/** PNG screenshot, base64 to stdout (no path given). */
export async function screenshot(session: string, opts: { full?: boolean; annotate?: boolean } = {}) {
  const args = [
    "screenshot",
    ...sessionArgs(session),
    ...(opts.full ? ["--full"] : []),
    ...(opts.annotate ? ["--annotate"] : []),
  ];
  return run(args, { timeoutMs: 15_000 });
}

export type BrowserAction =
  | { type: "click"; ref: string; newTab?: boolean }
  | { type: "dblclick"; ref: string }
  | { type: "hover"; ref: string }
  | { type: "focus"; ref: string }
  | { type: "type"; ref: string; text: string }
  | { type: "fill"; ref: string; text: string }
  | { type: "press"; key: string }
  | { type: "scroll"; dir: "up" | "down" | "left" | "right"; px?: number }
  | { type: "scrollintoview"; ref: string }
  | { type: "select"; ref: string; value: string }
  | { type: "check"; ref: string }
  | { type: "uncheck"; ref: string }
  | { type: "goto"; url: string }
  | { type: "back" }
  | { type: "forward" }
  | { type: "reload" }
  | { type: "eval"; js: string }
  | { type: "wait"; selector?: string; ms?: number; text?: string; load?: "networkidle" };

/** Execute a single structured action against a live session. */
export async function act(session: string, action: BrowserAction) {
  const s = sessionArgs(session);
  switch (action.type) {
    case "click":
      return run(["click", action.ref, ...s, ...(action.newTab ? ["--new-tab"] : []), "--json"]);
    case "dblclick":
      return run(["dblclick", action.ref, ...s, "--json"]);
    case "hover":
      return run(["hover", action.ref, ...s, "--json"]);
    case "focus":
      return run(["focus", action.ref, ...s, "--json"]);
    case "type":
      return run(["type", action.ref, action.text, ...s, "--json"]);
    case "fill":
      return run(["fill", action.ref, action.text, ...s, "--json"]);
    case "press":
      return run(["press", action.key, ...s, "--json"]);
    case "scroll":
      return run(["scroll", action.dir, ...(action.px ? [String(action.px)] : []), ...s, "--json"]);
    case "scrollintoview":
      return run(["scrollintoview", action.ref, ...s, "--json"]);
    case "select":
      return run(["select", action.ref, action.value, ...s, "--json"]);
    case "check":
      return run(["check", action.ref, ...s, "--json"]);
    case "uncheck":
      return run(["uncheck", action.ref, ...s, "--json"]);
    case "goto":
      return run(["open", action.url, ...s, "--json"]);
    case "back":
      return run(["eval", "window.history.back()", ...s, "--json"]);
    case "forward":
      return run(["eval", "window.history.forward()", ...s, "--json"]);
    case "reload":
      return run(["eval", "window.location.reload()", ...s, "--json"]);
    case "eval":
      return run(["eval", action.js, ...s, "--json"]);
    case "wait":
      return run([
        "wait",
        ...(action.selector ? [action.selector] : []),
        ...(action.ms ? [String(action.ms)] : []),
        ...(action.text ? ["--text", action.text] : []),
        ...(action.load ? ["--load", action.load] : []),
        ...s,
        "--json",
      ]);
  }
}

/** Agent-readable extracted text of the current page. */
export async function readPage(session: string) {
  return run(["read", ...sessionArgs(session), "--json"]);
}

export async function getText(session: string, ref: string) {
  return run(["get", "text", ref, ...sessionArgs(session), "--json"]);
}

export async function closeSession(session: string) {
  return run(["close", ...sessionArgs(session)]);
}

export async function listTabs(session: string) {
  return run(["tab", "list", ...sessionArgs(session), "--json"]);
}

export async function newTab(session: string, url?: string) {
  return run(["tab", "new", ...(url ? [url] : []), ...sessionArgs(session), "--json"]);
}

export async function cliVersion() {
  return run(["--version"]);
}
