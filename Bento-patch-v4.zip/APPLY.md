# AVA007 Cybernetic Console — patch v4 (architecture correction + accent)

## Read this first — architecture correction

Rescanning the repo turned up a new commit (`e1bc029`, "add:
document-ingestion, bash-api, esa, helpassembly modules (from core
membrane)") that adds a `CRITICAL ARCHITECTURAL BOUNDARY` section to
`AGENTS.md`. It states plainly:

> This repository (`Ava007-Console` / Web UI) is the **Orchestration and
> Intelligence Layer**... **DO NOT** look for or attempt to build the
> heavy-lifting edge SDKs here. `quantum-membrain` (DuckDB + Tashi DAG +
> Griptape TaskMemory)... reside in the dedicated `Agent-X` repository and
> execute directly on the S26 Ultra via Termux... communicate via the A2A
> Protocol and Apache Arrow Flight. Treat the edge as a black box.

So "browser will be stored in Core-membrain" is real and correct as a
target, but the implementation is **not** "build a MemBrain store in this
Next.js app" — that would violate the boundary the repo itself just
declared. What's actually correct: this console dispatches an A2A call to
the edge `quantum-membrain` process and treats it as a black box.

This patch renames every "MemBrain" reference to `quantum-membrain` and
reframes the language around it as an A2A dispatch, not a local store
(`WorkflowPanel`, `BrowserPanel`'s Parser tab, `DevPanels`' Intelligence
Injection panel, `ScannerPanel`'s queue). No new backend was built for
it — that's edge/Termux work outside this repo's boundary, consistent with
what AGENTS.md now says explicitly.

## On bento.ui8.net/01/ — same position, still holding

I did not scrape or clone that page. It's a live demo for a paid commercial
UI kit; copying its specific card designs would be reproducing a shipped
product, not building from a spec. What's in this patch instead: a
Gruvbox accent variant (`theme-gruvbox`, toggle in System settings) pulled
from the terminal-color screenshots you sent, layered on top of the
existing dark-glass tokens without touching radius/shadow/layout. If there's
a specific card from that page you want, describe its behavior or send a
screenshot and I'll build an original version — same as I said last time.

## What's in this zip

Small, targeted diff — 7 files, not a full re-send of the whole tree:

- `ava-shell.css` — added `.theme-gruvbox` accent overlay.
- `AvaShell.tsx` — wires a `gruvbox` toggle state through to the shell root
  class and Settings panel.
- `OverviewPanels.tsx` — `SettingsPanel` now shows the palette toggle and a
  `Storage: quantum-membrain (edge, via A2A)` row.
- `WorkflowPanel.tsx`, `BrowserPanel.tsx`, `DevPanels.tsx`,
  `ScannerPanel.tsx` — MemBrain → quantum-membrain rename + A2A framing.

## Apply

```bash
cd Agent-X
unzip -o /path/to/ava007-console-patch-v4.zip -d .
cd platform && pnpm install && pnpm dev
```

This applies on top of v1+v2+v3 (still un-merged in the actual repo as of
this rescan — same note as last two patches).

## Verified

`pnpm install` clean, `tsc --noEmit` clean (same one pre-existing repo
error, unrelated), full `next build` — all 22 routes compile.
