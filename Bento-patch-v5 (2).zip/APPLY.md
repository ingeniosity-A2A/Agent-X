# AVA007 Cybernetic Console — patch v5 (Bento-Exoskel-UI components)

Built directly from the `Bento-Exoskel-UI Master Skill MD` doc and the
`furniture-card` HTML you uploaded — your own spec, implemented faithfully,
not the bento.ui8.net site.

## On "is the sliding and exploded lock feature activated" — yes, verified

The lock/slide mechanism in `DevExoskelCard.tsx` works like this:

1. The slide panel (`ui8-glass-overlay`) is positioned `left: 100%` —
   completely off-canvas to the right, same width as the card, `opacity: 0`.
2. Clicking the corner lock icon toggles `isUnlocked` state.
3. A real `useEffect` + `gsap.to()` call (not a CSS-only transition) animates:
   - **Unlock:** `xPercent: -100, opacity: 1` — slides the panel left by
     100% of its own width, landing it exactly over the front card, fully
     visible. `power3.out`, 0.5s.
   - **Lock:** `xPercent: 0, opacity: 0` — slides it back off-canvas.
     `power3.in`, 0.4s.
4. Respects `prefers-reduced-motion` (duration drops to 0 instead of
   skipping the state change).

This matches your spec's `4.3 Inline GSAP DEV Drawer Component` exactly —
I only changed the lock emoji (🔒/🔓) to real `lucide-react` `Lock`/`Unlock`
icons, since your own doc lists Lucide as the icon library and `lucide-react`
was already a dependency in the repo.

I verified this by full `tsc --noEmit` + `next build` (both clean — see
below), which confirms the component compiles and the GSAP calls are
correctly typed and reachable. I can't click through the animation myself
in this sandbox (no browser), so "activated" here means: the code path
that drives it is real, wired to a real click handler, and builds clean —
not that I watched it animate. Test it live at `/console` → Dev →
Benchmarks tab once you `pnpm dev` this.

## What's new in this pass

- **`TelemetryShareCard.tsx`** — §4.1: waveform card with the grid-line
  viewport background, floating glass overlay, and the owner name badge.
  Bar heights are the literal array from your spec — not random per
  render, so it looks identical to your example every load. `owner` prop
  defaults to "Artur" (your spec's example) but is overridable.
- **`ActuatorFurnitureCard4.tsx`** — §4.2: torque readout in the main
  viewport + the far-right scroll wheel selector, same structure as your
  `FurnitureCard4` from before but matching this spec's exact exoskel
  tokens/dimensions instead of the bento tokens. Both now exist side by
  side in `Viewport.tsx`'s card registry — didn't delete the earlier one
  since you didn't ask me to.
- **`DevExoskelCard.tsx`** — §4.3, described above. Wired into
  `DevPanels.tsx`'s Benchmarks tab, above the older `DevFeatureCard` (also
  kept, labeled "v1", so you can compare both lock mechanisms side by side
  before deciding which to keep).
- **`ava-shell.css`** — added the full `--exoskel-*` token set from your
  doc verbatim (`#18181b`, `#242427`, `#1c1c1f`, the glass-tinted rgba
  values, the three radii), plus `.exoskel-card`, `.exoskel-viewport`,
  `.exoskel-scroll-wheel` utility classes so all three new components share
  one consistent base.

## Apply

```bash
cd Agent-X
unzip -o /path/to/ava007-console-patch-v5.zip -d .
cd platform && pnpm install && pnpm dev
```

Open `/console` → Viewport for Telemetry Share + Actuator Preset cards,
Dev → Benchmarks for the lock/slide DevExoskelCard.

## Verified

`pnpm install` clean, `tsc --noEmit` clean (same one pre-existing
`a2ui/types.ts` error, unrelated to this patch), full `next build` — all
22 routes compile, GSAP slide logic included and type-checked.
