"use client";

import { DevFeatureCard } from "../shell/DevFeatureCard";
import { DevExoskelCard } from "../shell/DevExoskelCard";

const BENCH_ROWS = [
  { model: "OpenRouter · Nemotron Nano 9B v2", ttft: "112ms", tps: "81", score: "—" },
  { model: "Xiaomi MiMo", ttft: "187ms", tps: "64", score: "—" },
  { model: "Z.ai", ttft: "91ms", tps: "93", score: "—" },
];

export function BenchmarksPanel() {
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
      <DevExoskelCard
        diagnostics={[
          { label: "session", value: "connected" },
          { label: "lock_state", value: "toggleable — click the corner icon" },
        ]}
      />
      <DevFeatureCard title="DEV Capabilities (v1)" subtitle="Unlock to expand inline">
        <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
          <span className="ava-badge">Repository benchmarks</span>
          <span className="ava-badge">Intelligence injection log</span>
          <span className="ava-badge">Runtime process list</span>
        </div>
      </DevFeatureCard>

      <div className="bento-card bento-card--elevated" style={{ padding: 18 }}>
      <div style={{ fontSize: 13, fontWeight: 600, marginBottom: 4 }}>Capability Substrate Benchmarks</div>
      <div style={{ fontSize: 11.5, color: "var(--bento-text-muted)", marginBottom: 16 }}>
        Shared Intent/CapabilityResult contract across OpenRouter, Xiaomi MiMo, and Z.ai. Scores intentionally blank
        here — plug in your real tiktoken/perf_counter benchmark harness output to fill this table, no mock numbers.
      </div>
      <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 12 }}>
        <thead>
          <tr style={{ textAlign: "left", color: "var(--bento-text-muted)" }}>
            <th style={{ padding: "8px 10px", fontWeight: 500 }}>Model</th>
            <th style={{ padding: "8px 10px", fontWeight: 500 }}>TTFT</th>
            <th style={{ padding: "8px 10px", fontWeight: 500 }}>tok/s</th>
            <th style={{ padding: "8px 10px", fontWeight: 500 }}>Score</th>
          </tr>
        </thead>
        <tbody>
          {BENCH_ROWS.map((r) => (
            <tr key={r.model} className="bento-card--inset" style={{ borderRadius: 10 }}>
              <td style={{ padding: "10px" }}>{r.model}</td>
              <td className="mono" style={{ padding: "10px" }}>{r.ttft}</td>
              <td className="mono" style={{ padding: "10px" }}>{r.tps}</td>
              <td className="mono" style={{ padding: "10px" }}>{r.score}</td>
            </tr>
          ))}
        </tbody>
      </table>
      </div>
    </div>
  );
}

const INJECTION_SOURCES = ["Model", "Repository", "Documentation", "Benchmark", "Browser", "Artifact"];

export function IntelligenceInjectionPanel() {
  return (
    <div className="bento-card bento-card--elevated" style={{ padding: 18 }}>
      <div style={{ fontSize: 13, fontWeight: 600, marginBottom: 4 }}>Intelligence Injection</div>
      <div style={{ fontSize: 11.5, color: "var(--bento-text-muted)", marginBottom: 16 }}>
        Source → Curator → Validation → an A2A call to <span className="mono">quantum-membrain</span> (edge, not
        built here) → Intellect. Evidence-class discipline applies: every claim entering this pipeline needs a
        dated, verifiable source before it reaches the edge store.
      </div>
      <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
        {INJECTION_SOURCES.map((s) => (
          <span key={s} className="ava-badge">
            {s}
          </span>
        ))}
      </div>
    </div>
  );
}
