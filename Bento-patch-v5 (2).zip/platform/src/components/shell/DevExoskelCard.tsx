"use client";

import { useEffect, useRef, useState } from "react";
import gsap from "gsap";
import { Lock, Unlock } from "lucide-react";

/**
 * Verbatim port of the spec's DevExoskelCard: the slide panel is absolutely
 * positioned at left:100% (fully off-canvas to the right, same width as the
 * card) and GSAP translates it by xPercent:-100 to slide it fully over the
 * front card on unlock — this is a cover/reveal transition, not a docked
 * side panel. Locking reverses it (xPercent:0, opacity:0, back off-canvas).
 * `diagnostics` accepts real key/value pairs to display — no invented
 * numbers are hardcoded here; pass real telemetry when you have it.
 */
export function DevExoskelCard({
  title = "DEV Capabilities",
  description = "Toggle lock to slide out inline diagnostics panel.",
  diagnosticsTitle = "Kernel Diagnostics",
  diagnostics,
}: {
  title?: string;
  description?: string;
  diagnosticsTitle?: string;
  diagnostics?: { label: string; value: string }[];
}) {
  const [isUnlocked, setIsUnlocked] = useState(false);
  const slidePanelRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!slidePanelRef.current) return;
    const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    if (isUnlocked) {
      gsap.to(slidePanelRef.current, {
        xPercent: -100,
        opacity: 1,
        duration: reduceMotion ? 0 : 0.5,
        ease: "power3.out",
      });
    } else {
      gsap.to(slidePanelRef.current, {
        xPercent: 0,
        opacity: 0,
        duration: reduceMotion ? 0 : 0.4,
        ease: "power3.in",
      });
    }
  }, [isUnlocked]);

  return (
    <div style={{ position: "relative", overflow: "hidden", width: 360, maxWidth: "100%" }}>
      <div className="bento-card-inverted-corner" style={{ width: "100%", padding: 24, borderRadius: "var(--exoskel-radius-card)", background: "var(--exoskel-card-dark)", border: "1px solid var(--exoskel-border-dark)", boxShadow: "0 25px 50px -12px rgba(0,0,0,0.5)", position: "relative" }}>
        <button
          onClick={() => setIsUnlocked((v) => !v)}
          className="exploded-lock-trigger"
          title={isUnlocked ? "Lock Panel" : "Unlock DEV Capabilities"}
        >
          {isUnlocked ? <Unlock size={14} /> : <Lock size={14} />}
        </button>

        <div style={{ paddingRight: 32 }}>
          <h3 style={{ fontSize: 16, fontWeight: 700, color: "#fff" }}>{title}</h3>
          <p style={{ fontSize: 11, color: "rgba(255,255,255,0.5)", marginTop: 4 }}>{description}</p>
        </div>
      </div>

      {/* GSAP animated slide-out panel — starts off-canvas right, opacity 0 */}
      <div
        ref={slidePanelRef}
        className="ui8-glass-overlay"
        style={{
          position: "absolute",
          top: 0,
          left: "100%",
          width: "100%",
          height: "100%",
          padding: 24,
          borderRadius: "var(--exoskel-radius-card)",
          display: "flex",
          flexDirection: "column",
          justifyContent: "space-between",
          opacity: 0,
        }}
      >
        <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
          <h4 style={{ fontSize: 13, fontWeight: 700, color: "#fff", textTransform: "uppercase", letterSpacing: "0.05em" }}>
            {diagnosticsTitle}
          </h4>
          <div className="mono" style={{ fontSize: 11, color: "#7ec8a0", background: "rgba(0,0,0,0.5)", padding: 12, borderRadius: 12, border: "1px solid rgba(255,255,255,0.1)", display: "flex", flexDirection: "column", gap: 4 }}>
            {(diagnostics ?? []).length === 0 ? (
              <div style={{ color: "rgba(255,255,255,0.4)" }}>No diagnostics feed connected.</div>
            ) : (
              diagnostics!.map((d) => (
                <div key={d.label}>
                  {d.label}: {d.value}
                </div>
              ))
            )}
          </div>
        </div>
        <button
          onClick={() => setIsUnlocked(false)}
          style={{ padding: "6px 16px", fontSize: 11, color: "rgba(255,255,255,0.7)", background: "rgba(255,255,255,0.1)", borderRadius: 999, border: "1px solid rgba(255,255,255,0.1)", cursor: "pointer", alignSelf: "flex-start" }}
        >
          Close Panel
        </button>
      </div>
    </div>
  );
}
