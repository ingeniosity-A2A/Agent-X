"use client";

import { useCallback, useEffect, useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

if (typeof window !== "undefined") {
  gsap.registerPlugin(ScrollTrigger);
}

/**
 * Bento entrance reveal — §3.1 of the Bento UI8 Master Skills Set.
 * Cards matching `.bento-card` (or a custom selector) inside the returned
 * ref fade up + scale in with a staggered batch reveal as they enter view.
 * Respects prefers-reduced-motion by skipping straight to the end state.
 */
export function useBentoReveal(selector = ".bento-card") {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!containerRef.current) return;
    const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const cards = containerRef.current.querySelectorAll(selector);
    if (cards.length === 0) return;

    if (reduceMotion) {
      gsap.set(cards, { opacity: 1, y: 0, scale: 1 });
      return;
    }

    gsap.set(cards, { opacity: 0, y: 60, scale: 0.95 });

    const batch = ScrollTrigger.batch(cards, {
      onEnter: (els) => {
        gsap.to(els, {
          opacity: 1,
          y: 0,
          scale: 1,
          duration: 0.8,
          stagger: { amount: 0.6, from: "start", grid: "auto" },
          ease: "power3.out",
        });
      },
      start: "top 85%",
      once: true,
    });

    return () => {
      batch.forEach((st) => st.kill());
    };
  }, [selector]);

  return containerRef;
}

/**
 * 3D tilt-toward-cursor hover — §3.3 of the Bento UI8 Master Skills Set.
 * Intended for decorative/stat tiles, not panels containing form inputs
 * (a tilting text field or url bar is bad UX, so this is applied selectively
 * — see DataLayerCard / StatCard usage in Viewport and OverviewPanels).
 */
export function useTilt3D(intensity = 12) {
  const cardRef = useRef<HTMLDivElement>(null);

  const handleMouseMove = useCallback(
    (e: React.MouseEvent) => {
      if (!cardRef.current) return;
      const rect = cardRef.current.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      const centerX = rect.width / 2;
      const centerY = rect.height / 2;

      const rotateX = ((y - centerY) / centerY) * -intensity;
      const rotateY = ((x - centerX) / centerX) * intensity;

      gsap.to(cardRef.current, {
        rotateX,
        rotateY,
        transformPerspective: 800,
        duration: 0.4,
        ease: "power2.out",
      });
    },
    [intensity],
  );

  const handleMouseLeave = useCallback(() => {
    if (!cardRef.current) return;
    gsap.to(cardRef.current, {
      rotateX: 0,
      rotateY: 0,
      duration: 0.6,
      ease: "elastic.out(1, 0.5)",
    });
  }, []);

  return { cardRef, handleMouseMove, handleMouseLeave };
}

/**
 * Slide-out drawer animation for the Inverted-Corner DEV lock card.
 * Slides the panel in from the right / fades it out when re-locked —
 * lets a DEV/feature surface expand inline without navigating away.
 */
export function useDevSlideOut(isLocked: boolean) {
  const panelRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!panelRef.current) return;
    const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    if (!isLocked) {
      gsap.to(panelRef.current, {
        xPercent: 0,
        opacity: 1,
        duration: reduceMotion ? 0 : 0.6,
        ease: "power3.out",
      });
    } else {
      gsap.to(panelRef.current, {
        xPercent: 100,
        opacity: 0,
        duration: reduceMotion ? 0 : 0.4,
        ease: "power3.in",
      });
    }
  }, [isLocked]);

  return panelRef;
}
