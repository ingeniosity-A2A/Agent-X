# AVA007 Cybernetic Console — patch v6 (glass-gel / punch-out restyle pack)

## Source check

The seven zips you uploaded are MIT-licensed CodePen demos (each has a
`LICENSE.txt` — copyright Simey, codepen.io/simeydotme). MIT permits reuse
and modification, so this pass adapts the underlying *techniques* into
original CSS written for this codebase (not copy-pasted from the demo
files), with attribution kept in a comment block in `ava-shell.css`.

Two of the seven weren't used this pass — `diagonally-responsive-form`
doesn't fit a fixed-size card grid, and `3d-css-grid-exploding-stack`
would change card dimensions on interaction, which conflicts with your
"doesn't change card height or width" constraint. Didn't force them in.

## What "doesn't change card height or width" meant in practice

Every change below is a **restyle of an element that already exists** —
same button, same padding, same container. Nothing new was added to any
card's layout flow:

- **Gel-glass progress meter** → `.gel-progress-track` / `.gel-progress-fill`.
  Added to `ActuatorFurnitureCard4`'s torque readout — but that readout
  sits inside `.exoskel-viewport`, which has a **fixed** 192px height
  regardless of content, so adding the bar inside it (via flex, centered)
  doesn't change the card's outer size. The bar's percentage is computed
  from the real `torqueValue`/`torqueMax` props, not a hardcoded number.
- **Gradient-mask button sheen** → `.gradient-mask-btn` (an `::before`
  overlay with a `mask-image` fade). Applied as an added className to
  five *existing* buttons (Close Panel, share arrow, Discover, Start
  camera, Capture) — zero layout properties touched, purely visual.
- **Punch-out border dots** → `.punch-border` (`mask-composite` dot grid
  on an `::after`, inset 10px, contained by the card's own
  `overflow: hidden`). Applied to `DevExoskelCard`, `TelemetryShareCard`,
  `ActuatorFurnitureCard4`. Purely decorative, position:absolute, adds
  nothing to flow.
- **Curved scrollbar** → restyled `::-webkit-scrollbar-thumb`/`-track` on
  the existing `.exoskel-scroll-wheel` / `.furniture-scroll-wheel`
  columns. Same 48px column width as before — only the scrollbar's own
  paint changed.

Glass-gel *slider* technique is in the CSS vocabulary now but I didn't
force it onto an existing control — none of the current cards have a
range input, and adding one would be a new element, which breaks your
"no size change" rule. Say where you want a slider and I'll add it
properly (which will add height, so flag if that's actually okay there).

## Apply

```bash
cd Agent-X
unzip -o /path/to/ava007-console-patch-v6.zip -d .
cd platform && pnpm dev
```

No new dependencies — pure CSS + prop plumbing, `pnpm install` not
required for this patch specifically (still fine to run).

## Verified

`tsc --noEmit` clean (same one pre-existing `a2ui/types.ts` error, not
mine), full `next build` — all 22 routes compile clean with the restyled
components.
