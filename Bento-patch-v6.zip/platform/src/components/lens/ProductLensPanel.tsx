"use client";

import { useEffect, useRef, useState } from "react";
import { IconCamera } from "../shell/icons";

/**
 * Product Lens — Exoskeleton sensor capability.
 * Camera capture is real (getUserMedia). SKU/product identification and
 * catalog lookup are stubbed pending the HD Supply catalog match endpoint
 * (see `/api/esa/lens` in the ESA Exoskeleton console) — this panel is
 * built to POST the captured frame there once ready.
 */
export default function ProductLensPanel() {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [streaming, setStreaming] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [capture, setCapture] = useState<string | null>(null);

  useEffect(() => {
    return () => {
      const stream = videoRef.current?.srcObject as MediaStream | null;
      stream?.getTracks().forEach((t) => t.stop());
    };
  }, []);

  const startCamera = async () => {
    setError(null);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: "environment" } });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play();
      }
      setStreaming(true);
    } catch {
      setError("Camera permission denied or unavailable in this browser context.");
    }
  };

  const takeShot = () => {
    if (!videoRef.current || !canvasRef.current) return;
    const v = videoRef.current;
    const c = canvasRef.current;
    c.width = v.videoWidth;
    c.height = v.videoHeight;
    c.getContext("2d")?.drawImage(v, 0, 0);
    setCapture(c.toDataURL("image/jpeg", 0.85));
  };

  return (
    <div className="bento-grid" style={{ gridTemplateColumns: "1.3fr 1fr" }}>
      <div className="bento-card bento-card--elevated" style={{ padding: 14 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 10 }}>
          <IconCamera style={{ width: 16, height: 16, opacity: 0.7 }} />
          <span style={{ fontSize: 13, fontWeight: 600 }}>Product Lens</span>
        </div>
        <div
          className="bento-card--inset"
          style={{ borderRadius: 20, minHeight: 340, display: "flex", alignItems: "center", justifyContent: "center", overflow: "hidden" }}
        >
          {streaming ? (
            <video ref={videoRef} muted playsInline style={{ width: "100%", height: "100%", objectFit: "cover" }} />
          ) : (
            <div style={{ textAlign: "center", padding: 24, color: "var(--bento-text-muted)", fontSize: 12.5 }}>
              {error || "Camera not started."}
            </div>
          )}
          <canvas ref={canvasRef} style={{ display: "none" }} />
        </div>
        <div style={{ display: "flex", gap: 10, marginTop: 12 }}>
          {!streaming ? (
            <button className="ava-icon-btn primary gradient-mask-btn" style={{ width: "auto", borderRadius: 999, padding: "9px 18px", fontSize: 12.5 }} onClick={startCamera}>
              Start camera
            </button>
          ) : (
            <button className="ava-icon-btn primary gradient-mask-btn" style={{ width: "auto", borderRadius: 999, padding: "9px 18px", fontSize: 12.5 }} onClick={takeShot}>
              Capture
            </button>
          )}
        </div>
      </div>

      <div className="bento-card" style={{ padding: 16 }}>
        <div style={{ fontSize: 12.5, fontWeight: 600, marginBottom: 10 }}>Identification</div>
        {capture ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={capture} alt="captured product" style={{ width: "100%", borderRadius: 14, marginBottom: 12 }} />
        ) : (
          <div style={{ fontSize: 12, color: "var(--bento-text-muted)", marginBottom: 12 }}>Capture a product to identify it.</div>
        )}
        <Field label="SKU" value={capture ? "—" : "—"} />
        <Field label="Product" value={capture ? "Pending catalog match" : "—"} />
        <Field label="Qty" value="?" />
        <div style={{ fontSize: 10.5, color: "var(--bento-text-muted)", marginTop: 12, lineHeight: 1.5 }}>
          Wire this card to your existing <span className="mono">/api/esa/lens</span> photo-to-inventory endpoint to
          replace the placeholder fields above with a real HD Supply catalog match.
        </div>
      </div>
    </div>
  );
}

function Field({ label, value }: { label: string; value: string }) {
  return (
    <div className="bento-card--inset" style={{ borderRadius: 10, padding: "8px 12px", display: "flex", justifyContent: "space-between", marginBottom: 8, fontSize: 12 }}>
      <span style={{ color: "var(--bento-text-muted)" }}>{label}</span>
      <span className="mono">{value}</span>
    </div>
  );
}
