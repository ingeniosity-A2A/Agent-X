# Freebuff execution sequence

From the AVA007 repository root:

```bash
cargo check
cargo run --release
```

Health:

```bash
curl -s http://127.0.0.1:8770/healthz
```

Inference:

```bash
curl -s http://127.0.0.1:8770/v1/kernel/infer \
  -H 'content-type: application/json' \
  -d '{
    "intent":"open browser and ingest PDF",
    "evidence":["browser download available"],
    "model":"local"
  }'
```

Expected behavior:

1. Intellect receives the request.
2. Inferential Kernel produces a typed inference result.
3. Kernel proposes an Exoskeleton capability.
4. Freebuff/existing runtime performs the authorized capability.
5. Result/telemetry is returned as an observation.
6. The next inference sees that observation.

This is the Figure-8 integration point.
